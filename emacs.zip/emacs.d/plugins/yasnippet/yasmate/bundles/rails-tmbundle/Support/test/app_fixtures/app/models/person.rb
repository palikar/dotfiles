class Person < ActiveRecord::Base
end